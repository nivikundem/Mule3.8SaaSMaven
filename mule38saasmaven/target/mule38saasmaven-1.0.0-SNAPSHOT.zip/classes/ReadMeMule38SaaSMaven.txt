# MULE38SaaSMaven
Demo for using Mule38 SaaS/Salesforce Connector and Batch Processing 
Mule3.8 Demo for using - Salesforce/SaaS[Software as a service] CRUD operations, batch processing, Topic subscription using Maven
--------------
Mule3.8 Demo for using - Salesforce/SaaS[Software as a service] CRUD operations, batch processing, Topic subscription using Maven


This project 
---------
Using Mule Salesforce connector performs CRUD operations and Topic Subscription



Mule components
---------
1.Dataweave
2.Salesforce Create/Update Single/Delete
3.Salesforce Subscribe Topic
3.Batch Processing
4.Database
5.http
6.Java component
3.Context property place folders
4.Message Properties transformer
5.VM Inbound/Outbound
6.Object-to-JSON
7.Exception Strategies




To Run
-------
Run as mule server or deploy into the mule sever as Mule Deployable Archive war,  by copy into the mule-standalone/apps


Technologies
---------
- J2E
- MySQL
- MULE ESB 3.8
- SaaS{Salesforce 7.2.0}
- Maven
